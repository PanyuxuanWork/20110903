using Sirenix.OdinInspector;
using System;
using System.Runtime.CompilerServices;
using UnityEditor;
using UnityEngine;
using UnityEngine.Serialization;

[CreateAssetMenu(fileName = "CustomAsset", menuName = "GridAsset")]
[Serializable]
public class GridAsset : ScriptableObject
{
    [Header("����")] public byte ID;

    [ReadOnly] public float CellWidth = 1.0f;   // ÿ��߳�
    [ReadOnly] public Vector2 OriginXZ;         // �������½ǣ����뵽CellWidth����������
    [ReadOnly] public int Width;                // X�������
    [ReadOnly] public int Height;               // Z������������ Y��
    public Area parent;

    [FormerlySerializedAs("Buildable")]
    [Header("һά��������index = x + width * z")]

    [ReadOnly, Tooltip("0-�ⲿ����,1-��·,7-����ռ��")]
    public byte[] passableType;

    [Header("�߶�(Y)")]
    [ReadOnly, Tooltip("ÿ�����ӵ�����߶�Y���� index = x + width * z �洢")]
    public float[] heightY;

#if UNITY_EDITOR
    [PropertySpace(8)]
    [BoxGroup("��������")]
    [InfoBox("ȷ�����鳤���� Width*Height ƥ�䣻�粻ƥ����Զ��ؽ���", InfoMessageType = InfoMessageType.None)]
    [Button("�ؽ�����ߴ磨Width*Height��", ButtonSizes.Medium)]
    [GUIColor(0.4f, 0.8f, 1f)]
    private void RebuildArrays()
    {
        EnsureArraySize(forceRecreate: true);
        UnityEditor.EditorUtility.SetDirty(this);
    }

    [BoxGroup("��������")]
    [Button("��ָ��ֵ��䡾ͨ������ & �߶ȡ�", ButtonSizes.Medium)]
    private void FillAll([LabelText("ͨ��(byte)")] byte passable = 1,
                         [LabelText("�߶�Y(float)")] float y = 0f)
    {
        EnsureArraySize();
        for (int i = 0, n = passableType.Length; i < n; i++) passableType[i] = passable;
        for (int i = 0, n = heightY.Length; i < n; i++) heightY[i] = y;
        UnityEditor.EditorUtility.SetDirty(this);
    }

    [BoxGroup("��������")]
    [Button("�����ͨ������", ButtonSizes.Small)]
    private void FillPassable([LabelText("ͨ��(byte)")] byte passable = 1)
    {
        EnsureArraySize();
        for (int i = 0, n = passableType.Length; i < n; i++) passableType[i] = passable;
        UnityEditor.EditorUtility.SetDirty(this);
    }

    [BoxGroup("��������")]
    [Button("�����߶�Y", ButtonSizes.Small)]
    private void FillHeight([LabelText("�߶�Y(float)")] float y = 0f)
    {
        EnsureArraySize();
        for (int i = 0, n = heightY.Length; i < n; i++) heightY[i] = y;
        UnityEditor.EditorUtility.SetDirty(this);
    }
#endif

    // �D�D ���߷���������ʱ O(1)���D�D

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public int ToIndex(int x, int z)
    {
        return x + Width * z; // Լ����x + width * z
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public bool WorldToCell(Vector3 world, out int x, out int z)
    {
        x = (int)Mathf.Floor((world.x - OriginXZ.x) / CellWidth);
        z = (int)Mathf.Floor((world.z - OriginXZ.y) / CellWidth);
        return (uint)x < (uint)Width && (uint)z < (uint)Height;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public int WorldToIndex(Vector3 world)
    {
        int x, z;
        if (!WorldToCell(world, out x, out z)) return -1;
        return ToIndex(x, z);
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public Vector3 IndexToWorldCenter(int index)
    {
        int x = index % Width;
        int z = index / Width;
        float cx = OriginXZ.x + (x + 0.5f) * CellWidth;
        float cz = OriginXZ.y + (z + 0.5f) * CellWidth;
        float cy = (heightY != null && (uint)index < (uint)heightY.Length) ? heightY[index] : 0f;
        return new Vector3(cx, cy, cz);
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public bool ContainsWorld(in Vector3 world)
    {
        int x, z;
        return WorldToCell(world, out x, out z);
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public bool ContainsWorldXZ(float worldX, float worldZ)
    {
        int x = (int)Mathf.Floor((worldX - OriginXZ.x) / CellWidth);
        int z = (int)Mathf.Floor((worldZ - OriginXZ.y) / CellWidth);
        return (uint)x < (uint)Width && (uint)z < (uint)Height;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public int TryWorldToIndex(in Vector3 world) => WorldToIndex(world);

    public Bounds GetWorldBoundsXZ()
    {
        Vector3 min = new Vector3(OriginXZ.x, 0f, OriginXZ.y);
        Vector3 size = new Vector3(Width * CellWidth, 0f, Height * CellWidth);
        Vector3 center = min + new Vector3(size.x * 0.5f, 0f, size.z * 0.5f);
        return new Bounds(center, new Vector3(size.x, 0.01f, size.z));
    }

    // �D�D �߶ȶ�д��ݷ��� �D�D

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public float GetHeight(int x, int z)
    {
        int idx = ToIndex(x, z);
        if (heightY == null || (uint)idx >= (uint)heightY.Length) return 0f;
        return heightY[idx];
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public void SetHeight(int x, int z, float y)
    {
        int idx = ToIndex(x, z);
        if (heightY == null || (uint)idx >= (uint)heightY.Length) return;
        heightY[idx] = y;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public byte GetPassable(int x, int z)
    {
        int idx = ToIndex(x, z);
        if (passableType == null || (uint)idx >= (uint)passableType.Length) return 0;
        return passableType[idx];
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public void SetPassable(int x, int z, byte v)
    {
        int idx = ToIndex(x, z);
        if (passableType == null || (uint)idx >= (uint)passableType.Length) return;
        passableType[idx] = v;
    }

    // �D�D �ڲ����� �D�D
    private void OnValidate()
    {
        EnsureArraySize();
    }

    private void EnsureArraySize(bool forceRecreate = false)
    {
        int n = Mathf.Max(Width * Height, 0);

        if (forceRecreate || passableType == null || passableType.Length != n)
            passableType = (n > 0) ? new byte[n] : Array.Empty<byte>();

        if (forceRecreate || heightY == null || heightY.Length != n)
            heightY = (n > 0) ? new float[n] : Array.Empty<float>();
    }


}
